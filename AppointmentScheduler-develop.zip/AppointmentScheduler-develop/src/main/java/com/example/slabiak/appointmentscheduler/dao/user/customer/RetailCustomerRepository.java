package com.example.slabiak.appointmentscheduler.dao.user.customer;

import com.example.slabiak.appointmentscheduler.dao.user.CommonUserRepository;
import com.example.slabiak.appointmentscheduler.entity.user.customer.RetailCustomer;

public interface RetailCustomerRepository extends CommonUserRepository<RetailCustomer> {
}
